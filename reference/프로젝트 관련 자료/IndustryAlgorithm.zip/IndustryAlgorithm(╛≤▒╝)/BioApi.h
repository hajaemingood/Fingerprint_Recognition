#ifndef _BIOAPI_H
#define _BIOAPI_H

#ifndef _KISA_IMPORT
#define KISADLL  extern "C" __declspec(dllexport)
#else
#define KISADLL	extern "C" __declspec(dllimport)
#endif

typedef char			sint8;
typedef short			sint16;
typedef long			sint32;

typedef unsigned char	uint8;
typedef unsigned short	uint16;
typedef unsigned long	uint32;

typedef uint8  BioAPI_BIR_VERSION, *BioAPI_BIR_VERSION_PTR;

typedef uint8 BioAPI_BIR_DATA_TYPE;  
#define	BioAPI_BIR_DATA_TYPE_RAW			(0x01)
#define	BioAPI_BIR_DATA_TYPE_INTERMEDIATE	(0x02)
#define	BioAPI_BIR_DATA_TYPE_PROCESSED		(0x04)
#define	BioAPI_BIR_DATA_TYPE_ENCRYPTED		(0x10)
#define	BioAPI_BIR_DATA_TYPE_SIGNED			(0x20)

typedef struct bioapi_bir_biometric_data_format {
	uint16 FormatOwner;
	uint16 FormatID;
} BioAPI_BIR_BIOMETRIC_DATA_FORMAT, *BioAPI_BIR_BIOMETRIC_DATA_FORMAT_PTR;

typedef  sint8  BioAPI_QUALITY;

typedef uint8 BioAPI_BIR_PURPOSE;
#define	BioAPI_PURPOSE_VERIFY 							(1)
#define	BioAPI_PURPOSE_IDENTIFY 						(2)
#define	BioAPI_PURPOSE_ENROLL							(3)
#define	BioAPI_PURPOSE_ENROLL_FOR_VERIFICATION_ONLY		(4)
#define	BioAPI_PURPOSE_ENROLL_FOR_IDENTIFICATION_ONLY	(5)
#define	BioAPI_PURPOSE_AUDIT							(6)

typedef uint32 BioAPI_BIR_AUTH_FACTORS;
#define	BioAPI_FACTOR_MULTIPLE				(0x00000001)
#define	BioAPI_FACTOR_FACIAL_FEATURES 		(0x00000002)
#define	BioAPI_FACTOR_VOICE					(0x00000004)
#define	BioAPI_FACTOR_FINGERPRINT	 		(0x00000008)
#define	BioAPI_FACTOR_IRIS					(0x00000010)
#define	BioAPI_FACTOR_RETINA 				(0x00000020)
#define	BioAPI_FACTOR_HAND_GEOMETRY			(0x00000040)
#define	BioAPI_FACTOR_SIGNATURE_DYNAMICS 	(0x00000080)
#define	BioAPI_FACTOR_KEYSTOKE_DYNAMICS		(0x00000100)
#define	BioAPI_FACTOR_LIP_MOVEMENT			(0x00000200)
#define	BioAPI_FACTOR_THERMAL_FACE_IMAGE	(0x00000400)
#define	BioAPI_FACTOR_THERMAL_HAND_IMAGE	(0x00000800)
#define	BioAPI_FACTOR_GAIT					(0x00001000)
#define	BioAPI_FACTOR_PASSWORD				(0x80000000)

typedef uint8 BioAPI_BIR_BIOMETRIC_DATA, *BioAPI_BIR_BIOMETRIC_DATA_PTR;

typedef struct bioapi_bir_header {
	uint32 Length;   /* Length of Header + Opaque Data */
	BioAPI_BIR_VERSION HeaderVersion;
	BioAPI_BIR_DATA_TYPE Type;
	BioAPI_BIR_BIOMETRIC_DATA_FORMAT Format;
	BioAPI_QUALITY Quality;
	BioAPI_BIR_PURPOSE Purpose;
	BioAPI_BIR_AUTH_FACTORS FactorsMask;
} BioAPI_BIR_HEADER, *BioAPI_BIR_HEADER_PTR;

typedef struct bioapi_data{
    uint32 Length;  /* in bytes */
    uint8 *Data;
} BioAPI_DATA, *BioAPI_DATA_PTR; 

typedef struct bioapi_bir {
	BioAPI_BIR_HEADER  Header;
	BioAPI_BIR_BIOMETRIC_DATA_PTR BiometricData;	/* length indicated in header */
	BioAPI_DATA_PTR Signature;		/* NULL if no signature; length is inherent in this type */
} BioAPI_BIR, *BioAPI_BIR_PTR;

typedef uint32 BioAPI_RETURN;
#define BioAPI_OK 	(0)

typedef struct bioapi_version {
    uint32 Major;
    uint32 Minor;
} BioAPI_VERSION, *BioAPI_VERSION_PTR;

typedef 	uint32 	BioAPI_HANDLE, *BioAPI_HANDLE_PTR;

typedef  sint32 BioAPI_BIR_HANDLE, *BioAPI_BIR_HANDLE_PTR;
#define	BioAPI_INVALID_BIR_HANDLE				(-1)
#define	BioAPI_UNSUPPORTED_BIR_HANDLE			(-2)

typedef uint8 BioAPI_INPUT_BIR_FORM;
#define	BioAPI_DATABASE_ID_INPUT 	(1)
#define	BioAPI_BIR_HANDLE_INPUT		(2)
#define	BioAPI_FULLBIR_INPUT 		(3)

typedef  sint32 BioAPI_DB_HANDLE, *BioAPI_DB_HANDLE_PTR;
#define	BioAPI_DB_INVALID_HANDLE		(-1)

typedef uint8  		BioAPI_UUID[16];
typedef	BioAPI_UUID	*BioAPI_UUID_PTR;

typedef  sint32  BioAPI_FAR, *BioAPI_FAR_PTR;
typedef  sint32  BioAPI_FRR, *BioAPI_FRR_PTR;

#define	BioAPI_NOT_SET				(-1)
#define	BioAPI_NOT_SET				(-1)
#define	BioAPI_NOT_SUPPORTED		(-2)

typedef  uint32 BioAPI_BOOL;
#define BioAPI_FALSE 		(0)
#define BioAPI_TRUE 		(!BioAPI_FALSE)

typedef struct bioapi_dbbir_id {
	BioAPI_DB_HANDLE DbHandle;
	BioAPI_UUID KeyValue;
} BioAPI_DBBIR_ID, *BioAPI_DBBIR_ID_PTR;

typedef struct bioapi_input_bir {
	BioAPI_INPUT_BIR_FORM Form;
	union {
	    BioAPI_DBBIR_ID_PTR  BIRinDb;
	    BioAPI_BIR_HANDLE_PTR  BIRinBSP;
	    BioAPI_BIR_PTR  BIR;
	} InputBIR;
} BioAPI_INPUT_BIR, *BioAPI_INPUT_BIR_PTR;


//////////////////////////////////////////////////////////////////////////
// Functions 
//////////////////////////////////////////////////////////////////////////

#ifndef _KISA_IMPORT

KISADLL BioAPI_RETURN  KISA_Init
	(const BioAPI_VERSION	*Version,
	uint32					Reserved1, 
	const void				*Reserved2,
	uint32					*Reserved3,
	const void				*Reserved4);

KISADLL BioAPI_RETURN  KISA_Terminate();

KISADLL BioAPI_RETURN  KISA_FreeBIRHandle 
	(BioAPI_HANDLE			ModuleHandle,
	BioAPI_BIR_HANDLE		Handle); 

KISADLL BioAPI_RETURN  KISA_GetBIRFromHandle 
	(BioAPI_HANDLE			ModuleHandle,
	BioAPI_BIR_HANDLE		Handle,
	BioAPI_BIR_PTR			*BIR);

KISADLL BioAPI_RETURN  KISA_Enroll
	(BioAPI_HANDLE			ModuleHandle,
	const BioAPI_INPUT_BIR  *CapturedBIR,
	const BioAPI_INPUT_BIR  *StoredTemplate,
	BioAPI_BIR_HANDLE_PTR	NewTemplate,
	const BioAPI_DATA		*Payload);

KISADLL BioAPI_RETURN KISA_Attemp
	(BioAPI_HANDLE			ModuleHandle,
	const BioAPI_INPUT_BIR  *CapturedBIR,
	BioAPI_BIR_HANDLE_PTR	ProcessedBIR);

KISADLL BioAPI_RETURN KISA_Compare
	(BioAPI_HANDLE			ModuleHandle,
	const BioAPI_FAR		*MaxFARRequested,
	const BioAPI_FRR		*MaxFRRRequested,
	const BioAPI_BOOL		*FARPrecedence,
	const BioAPI_INPUT_BIR  *ProcessedBIR,
	const BioAPI_INPUT_BIR  *StoredTemplate,
	BioAPI_BIR_HANDLE		*AdaptedBIR,
	BioAPI_BOOL				*Result,
	BioAPI_FAR_PTR			FARAchieved,
	BioAPI_FRR_PTR			FRRAchieved,
	BioAPI_DATA_PTR			*Payload);

#else

typedef BioAPI_RETURN (* BioAPI_INIT)
	(const BioAPI_VERSION	*Version,
	uint32					Reserved1, 
	const void				*Reserved2,
	uint32					*Reserved3,
	const void				*Reserved4);

typedef BioAPI_RETURN (* BioAPI_TERMINATE)();

typedef BioAPI_RETURN (* BioAPI_FREEBIRHANDLE) 
	(BioAPI_HANDLE			ModuleHandle,
	BioAPI_BIR_HANDLE		Handle); 

typedef BioAPI_RETURN (* BioAPI_GETBIRFROMHANDLE)
	(BioAPI_HANDLE			ModuleHandle,
	BioAPI_BIR_HANDLE		Handle,
	BioAPI_BIR_PTR			*BIR);

typedef BioAPI_RETURN (* BioAPI_CREATETEMPLATE)
	(BioAPI_HANDLE			ModuleHandle,
	const BioAPI_INPUT_BIR  *CapturedBIR,
	const BioAPI_INPUT_BIR  *StoredTemplate,
	BioAPI_BIR_HANDLE_PTR	NewTemplate,
	const BioAPI_DATA		*Payload);

typedef BioAPI_RETURN (* BioAPI_PROCESS)
	(BioAPI_HANDLE			ModuleHandle,
	const BioAPI_INPUT_BIR  *CapturedBIR,
	BioAPI_BIR_HANDLE_PTR	ProcessedBIR);

typedef BioAPI_RETURN (* BioAPI_VERIFYMATCH)
	(BioAPI_HANDLE			ModuleHandle,
	const BioAPI_FAR		*MaxFARRequested,
	const BioAPI_FRR		*MaxFRRRequested,
	const BioAPI_BOOL		*FARPrecedence,
	const BioAPI_INPUT_BIR  *ProcessedBIR,
	const BioAPI_INPUT_BIR  *StoredTemplate,
	BioAPI_BIR_HANDLE		*AdaptedBIR,
	BioAPI_BOOL				*Result,
	BioAPI_FAR_PTR			FARAchieved,
	BioAPI_FRR_PTR			FRRAchieved,
	BioAPI_DATA_PTR			*Payload);

#endif // _KISA_IMPORT

#endif // _BIOAPI_H
