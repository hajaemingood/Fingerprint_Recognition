#ifndef _BIOAPI_H
#define _BIOAPI_H

#ifndef _KISA_IMPORT
#define KISADLL  extern "C" __declspec(dllexport)
#else
#define KISADLL	extern "C" __declspec(dllimport)
#endif

KISADLL bool KISA_Enroll(BYTE *VeinIMG, int width, int height, BYTE *EnrollVeinCode);	
KISADLL bool KISA_Attempt(BYTE *VeinIMG, int width, int height, BYTE *RecogVeinCode);
KISADLL float KISA_Compare(BYTE *EnrollVeinCode, BYTE *RecogVeinCode);

#endif